// config used by store client side only
module.exports = {
	// store UI language
	language: 'en',
	ajaxBaseUrl: '/ajax'
};
