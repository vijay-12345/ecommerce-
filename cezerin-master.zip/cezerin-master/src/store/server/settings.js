import settings from '../../../config/server';
export default settings;
