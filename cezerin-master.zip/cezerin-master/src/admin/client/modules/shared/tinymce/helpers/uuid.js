let count = 0;
export default function uuid() {
	return 'react-tinymce-' + count++;
}
