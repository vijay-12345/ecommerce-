export default function ucFirst(str) {
	return str[0].toUpperCase() + str.substring(1);
}
